// lordApp.cpp
// client file for apart program
#include "landlord.h"

int main()
   {
   userInterface theUserInterface;

   theUserInterface.interact();
   return 0;
   }
////////////////////////end file lordApp.cpp////////////////////
