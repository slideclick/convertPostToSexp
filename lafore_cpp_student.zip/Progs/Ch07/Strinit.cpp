// strinit.cpp
// initialized string
#include <iostream>
using namespace std;

int main()
   {
   char str[] = "Farewell! thou art too dear for my possessing.";
   cout << str << endl;
   return 0;
   }