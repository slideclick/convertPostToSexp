public interface Data {
    public abstract String getContent();
}
