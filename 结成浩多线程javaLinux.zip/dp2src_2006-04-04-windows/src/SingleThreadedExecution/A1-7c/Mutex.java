import java.util.concurrent.locks.ReentrantLock;

public class Mutex extends ReentrantLock {
}
