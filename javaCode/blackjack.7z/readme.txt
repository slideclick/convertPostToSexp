javac -cp .;stdlib.jar BlackJack.java
java -cp .;cards.jar BlackJack