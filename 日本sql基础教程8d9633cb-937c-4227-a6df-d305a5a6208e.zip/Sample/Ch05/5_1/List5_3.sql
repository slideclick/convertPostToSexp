SELECT product_type, cnt_product
  FROM ProductSum;