SELECT MAX(sale_price), MIN(purchase_price)
  FROM Product;