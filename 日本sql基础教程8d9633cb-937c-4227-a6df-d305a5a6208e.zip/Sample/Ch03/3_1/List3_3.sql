SELECT COUNT(*), COUNT(col_1)
  FROM NullTbl;