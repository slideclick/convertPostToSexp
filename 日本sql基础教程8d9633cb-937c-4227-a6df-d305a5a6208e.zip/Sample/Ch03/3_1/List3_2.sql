SELECT COUNT(purchase_price)
  FROM Product;