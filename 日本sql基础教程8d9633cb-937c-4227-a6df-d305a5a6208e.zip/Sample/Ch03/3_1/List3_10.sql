SELECT COUNT(DISTINCT product_type)
  FROM Product;