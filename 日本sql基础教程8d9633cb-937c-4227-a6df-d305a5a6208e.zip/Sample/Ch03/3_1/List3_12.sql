SELECT SUM(sale_price), SUM(DISTINCT sale_price)
  FROM Product;