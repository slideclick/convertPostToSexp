SELECT SUM(sale_price)
  FROM Product;