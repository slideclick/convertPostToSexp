SELECT COUNT(*)
  FROM Product;