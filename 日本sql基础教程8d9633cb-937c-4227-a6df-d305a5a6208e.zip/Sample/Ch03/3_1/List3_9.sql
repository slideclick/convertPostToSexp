SELECT MAX(regist_date), MIN(regist_date)
  FROM Product;