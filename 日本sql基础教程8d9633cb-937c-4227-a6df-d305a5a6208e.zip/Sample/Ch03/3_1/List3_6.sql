SELECT AVG(sale_price)
  FROM Product;