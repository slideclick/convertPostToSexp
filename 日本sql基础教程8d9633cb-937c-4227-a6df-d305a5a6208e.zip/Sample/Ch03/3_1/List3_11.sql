SELECT DISTINCT COUNT(product_type)
  FROM Product;