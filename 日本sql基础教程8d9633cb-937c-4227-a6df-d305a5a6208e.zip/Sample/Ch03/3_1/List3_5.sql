SELECT SUM(sale_price), SUM(purchase_price)
  FROM Product;