SELECT AVG(sale_price), AVG(purchase_price)
  FROM Product;