SELECT product_name, sale_price, purchase_price
  FROM Product
ORDER BY product_id;