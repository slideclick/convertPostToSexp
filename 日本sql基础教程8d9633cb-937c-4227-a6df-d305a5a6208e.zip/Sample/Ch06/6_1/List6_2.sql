SELECT m,
       ABS(m) AS abs_col
  FROM SampleMath;