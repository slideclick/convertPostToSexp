--Oracle, DB2, PostgreSQL
SELECT str1, str2,
       str1 || str2 AS str_concat
  FROM SampleStr;