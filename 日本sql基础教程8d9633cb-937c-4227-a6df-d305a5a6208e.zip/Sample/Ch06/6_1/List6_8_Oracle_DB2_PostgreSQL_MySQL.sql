--Oracle, DB2, PostgreSQL, MySQL
SELECT str1,
       LENGTH(str1) AS len_str
  FROM SampleStr;