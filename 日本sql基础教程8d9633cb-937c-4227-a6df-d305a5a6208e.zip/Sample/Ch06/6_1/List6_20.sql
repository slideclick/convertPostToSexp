SELECT COALESCE(str2, 'taNULL')
  FROM SampleStr;