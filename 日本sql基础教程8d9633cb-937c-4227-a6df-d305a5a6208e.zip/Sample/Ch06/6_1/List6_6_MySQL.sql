--MySQL
SELECT str1, str2,
       CONCAT(str1, str2) AS str_concat
  FROM SampleStr;