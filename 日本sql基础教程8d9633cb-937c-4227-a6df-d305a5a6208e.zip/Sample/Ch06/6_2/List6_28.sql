SELECT product_name, sale_price
  FROM Product
 WHERE sale_price > 100 
   AND sale_price < 1000;