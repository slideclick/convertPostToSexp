SELECT product_name, sale_price
  FROM Product
 WHERE sale_price BETWEEN 100 AND 1000;