SELECT product_name, product_type
  FROM Product
 WHERE sale_price < 1000;