SELECT product_name, product_type, regist_date
  FROM Product
 WHERE product_type = '�칫��Ʒ'
   AND regist_date = '2009-09-11'
    OR regist_date = '2009-09-20';