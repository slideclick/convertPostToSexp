SELECT product_name, product_type, sale_price
  FROM Product
 WHERE NOT sale_price >= 1000;