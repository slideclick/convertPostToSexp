SELECT DISTINCT product_type, regist_date
  FROM Product;