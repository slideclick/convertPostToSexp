SELECT product_name, product_type
  FROM Product
 WHERE product_type = '�·�';