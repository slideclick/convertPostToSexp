SELECT '��Ʒ' AS string, 38 AS number, '2009-02-24' AS date,
       product_id, product_name
  FROM Product;