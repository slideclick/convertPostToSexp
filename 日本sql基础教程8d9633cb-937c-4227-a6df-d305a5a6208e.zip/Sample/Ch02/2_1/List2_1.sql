SELECT product_id, product_name, purchase_price
  FROM Product;