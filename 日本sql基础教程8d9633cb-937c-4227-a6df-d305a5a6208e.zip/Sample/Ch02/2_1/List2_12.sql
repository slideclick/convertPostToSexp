SELECT product_name, product_type
 WHERE product_type = '�·�'
  FROM Product;