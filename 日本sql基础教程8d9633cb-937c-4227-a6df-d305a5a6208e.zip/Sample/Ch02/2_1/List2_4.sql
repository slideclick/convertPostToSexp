SELECT product_id    AS id,
       product_name  AS name,
       purchase_date AS price
  FROM Product;