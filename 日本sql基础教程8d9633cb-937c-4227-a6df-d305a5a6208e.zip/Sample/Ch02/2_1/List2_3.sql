SELECT product_id, product_name, product_type, sale_price,
       purchase_price, regist_date
  FROM Product;