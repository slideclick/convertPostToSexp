SELECT product_name
  FROM Product
 WHERE product_type = '�·�';