SELECT DISTINCT product_type
  FROM Product;