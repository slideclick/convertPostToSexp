SELECT *
  FROM Product;