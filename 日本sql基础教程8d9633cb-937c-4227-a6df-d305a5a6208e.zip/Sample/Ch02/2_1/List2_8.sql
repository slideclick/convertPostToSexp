SELECT DISTINCT purchase_price
  FROM Product;