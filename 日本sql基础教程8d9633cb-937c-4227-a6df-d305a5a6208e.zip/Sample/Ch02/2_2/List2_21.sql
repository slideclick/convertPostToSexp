SELECT product_name, product_type, regist_date
  FROM Product
 WHERE regist_date < '2009-09-27';