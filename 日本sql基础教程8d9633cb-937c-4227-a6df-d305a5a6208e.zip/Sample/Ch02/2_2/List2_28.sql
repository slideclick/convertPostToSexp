SELECT product_name, purchase_price
  FROM Product
 WHERE purchase_price IS NULL;