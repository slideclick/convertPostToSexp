SELECT product_name, sale_price,
       sale_price * 2 AS “sale_price_x2"
  FROM Product;