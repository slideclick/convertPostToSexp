SELECT chr
  FROM Chars
 WHERE chr > '2';