--Oracle
SELECT (100 + 200) * 3 AS calculation FROM DUAL;