SELECT product_id, product_name
  FROM Product
UNION
SELECT product_id, product_name
  FROM Product2;