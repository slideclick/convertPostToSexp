--MySQL
RENAME TABLE Poduct TO Product;