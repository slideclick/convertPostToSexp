--SQL Server
ALTER TABLE Product ADD product_name_pinyin VARCHAR(100);