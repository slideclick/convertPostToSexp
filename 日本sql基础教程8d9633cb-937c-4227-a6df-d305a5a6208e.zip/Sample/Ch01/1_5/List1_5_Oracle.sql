--Oracle
ALTER TABLE Product DROP (product_name_pinyin);