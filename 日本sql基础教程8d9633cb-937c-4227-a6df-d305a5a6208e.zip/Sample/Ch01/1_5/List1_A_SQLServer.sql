--SQL Server
sp_rename ‘Poduct’, ‘Product’;