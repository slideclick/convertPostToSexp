﻿—-Oracle
ALTER TABLE Product ADD (product_name_pinyin VARCHAR2(100));