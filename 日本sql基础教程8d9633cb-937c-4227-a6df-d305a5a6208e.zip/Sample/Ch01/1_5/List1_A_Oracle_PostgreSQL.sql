--Oracle PostgreSQL
ALTER TABLE Poduct RENAME TO Product;