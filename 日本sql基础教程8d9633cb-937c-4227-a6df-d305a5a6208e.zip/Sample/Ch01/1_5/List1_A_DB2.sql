--DB2
RENAME TABLE Poduct TO Product;