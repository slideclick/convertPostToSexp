INSERT INTO ProductIns (product_id, product_name, product_type, sale_price, purchase_price, regist_date) VALUES ('0001', 'T��' ,'�·�', 1000, 500, '2009-09-20');


/*
-- VALUES�嵥��ȱ��1��
INSERT INTO ProductIns (product_id, product_name, product_type, sale_price, purchase_price, regist_date) VALUES ('0001', 'T��' ,'�·�', 1000, 500);
*/