SELECT *
  FROM Product
 ORDER BY regist_date DESC, sale_price;