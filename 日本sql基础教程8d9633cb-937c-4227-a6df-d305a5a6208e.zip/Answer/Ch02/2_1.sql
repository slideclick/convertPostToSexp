SELECT product_name, regist_date
  FROM Product
 WHERE regist_date > '2009-04-28';