package activeobject;

public interface ActiveObject {
    public abstract Result<String> search(String word);
}
