package content;

public interface Content {
    public abstract byte[] getBytes();
}
